(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__1zdqg8i._.css","static/chunks/node_modules_0ti4qic._.js","static/chunks/app_components_07u3iqh._.js"],
    source: "dynamic"
});
